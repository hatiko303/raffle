// // DOM элементы
// const modalOverlay = document.getElementById('modal');
// const openModal = document.getElementById('openModal');
// const closeModal = document.getElementById('closeModal');
// const createBtn = document.getElementById('createRaffle');
// const rafflesList = document.getElementById('rafflesList');
// const participantsList = document.getElementById('participantsList');

// // Текущий выбранный розыгрыш
// let currentRaffleId = null;

// // WebSocket - будет инициализирован ПОСЛЕ проверки аутентификации
// let socket = null;

// // ===== ПРОВЕРКА АУТЕНТИФИКАЦИИ =====

// async function checkAuthentication() {
//   console.log('checkAuthentication вызвана');

//   try {
//     console.log('Делаем запрос к /auth/me...');
//     const response = await fetch('http://localhost:3000/auth/me', {
//       method: 'GET',
//       credentials: 'include'
//     });

//     console.log('Статус ответа:', response.status, response.statusText);

//     if (!response.ok) {
//       console.log('Пользователь не авторизован, перенаправляем на login.html через 3 секунды...');

//       // ⚠️ ВРЕМЕННО: задержка для отладки
//       setTimeout(() => {
//         window.location.href = 'login.html';
//       }, 3000);

//       return false;
//     }

//     const data = await response.json();
//     console.log('Данные ответа:', data);

//     if (data.ok && data.user) {
//       console.log('Пользователь авторизован:', data.user.username);
//       localStorage.setItem('user', JSON.stringify(data.user));
//       localStorage.removeItem('justLoggedIn');
//       return true;
//     } else {
//       console.log('Некорректные данные пользователя, перенаправляем через 3 секунды...');

//       // ⚠️ ВРЕМЕННО: задержка для отладки
//       setTimeout(() => {
//         window.location.href = 'login.html';
//       }, 500);

//       return false;
//     }
//   } catch (error) {
//     console.error('Ошибка в checkAuthentication:', error);
//     console.log('Перенаправляем на login.html через 3 секунды из-за ошибки');

//     // ⚠️ ВРЕМЕННО: задержка для отладки
//     setTimeout(() => {
//       window.location.href = 'login.html';
//     }, 5000);

//     return false;
//   }
// }

// // ===== ИНИЦИАЛИЗАЦИЯ WEB SOCKET =====

// function initWebSocket() {
//   if (typeof io === 'function') {
//     console.log('Инициализируем WebSocket соединение...');

//     // Получаем токен из localStorage или cookies
//     const token = localStorage.getItem('accessToken');

//     // Пробуем найти токен в cookies если нет в localStorage
//     let authToken = token;
//     if (!authToken) {
//       const cookies = document.cookie.split(';');
//       const accessTokenCookie = cookies.find(c => c.trim().startsWith('accessToken='));
//       if (accessTokenCookie) {
//         authToken = accessTokenCookie.split('=')[1];
//       }
//     }

//     console.log('WebSocket token:', authToken ? authToken.substring(0, 20) + '...' : 'НЕТ ТОКЕНА');

//     // Подключаемся с токеном
//     socket = io('http://localhost:3000', {
//       auth: {
//         token: authToken
//       },
//       transports: ['websocket', 'polling'], // Добавляем оба транспорта
//       withCredentials: true // Важно для cookies
//     });

//     // Настройка обработчиков WebSocket
//     setupSocketEvents();

//     console.log('WebSocket подключен');
//   } else {
//     console.error('socket.io не загружен!');
//   }
// }

// function setupSocketEvents() {
//   if (!socket) return;

//   socket.on('participantJoined', data => {
//     if (data.raffleId === currentRaffleId) {
//       const li = document.createElement('li');
//       li.className = 'new-participant';
//       li.innerHTML = `
//             <span style="background: rgba(0, 245, 255, 0.3); padding: 5px 10px; border-radius: 10px; font-size: 0.8rem;">
//                 🎉 NEW
//             </span>
//             ${data.user}
//             <span style="margin-left: auto; font-size: 0.8rem; opacity: 0.7;">
//                 Участник #${data.count}
//             </span>
//         `;
//       if (participantsList) {
//         participantsList.prepend(li);
//       }

//       // Обновляем счетчик
//       updateParticipantsCount(data.count);

//       // Показываем уведомление
//       showNotification(`🎯 Новый участник: ${data.user}`, 'info');
//     }
//   });

//   socket.on('participantsUpdate', data => {
//     displayParticipants(data.participants);
//     updateParticipantsCount(data.count);
//   });

//   socket.on('raffleCreated', () => {
//     loadRaffles();
//   });

//   socket.on('raffleStarted', data => {
//     showNotification(`🚀 Розыгрыш ${data.raffleId.substring(0, 8)} запущен`, 'success');
//   });

//   socket.on('raffleStopped', data => {
//     showNotification(`🛑 Розыгрыш остановлен. Участников: ${data.winnerCount}`, 'warning');
//   });
// }

// // ===== УПРАВЛЕНИЕ МОДАЛЬНЫМ ОКНОМ =====

// // Открытие модального окна
// openModal.addEventListener('click', () => {
//   modalOverlay.classList.add('active');
//   document.body.style.overflow = 'hidden'; // Блокируем скролл
// });

// // Закрытие модального окна
// closeModal.addEventListener('click', () => {
//   modalOverlay.classList.remove('active');
//   document.body.style.overflow = 'auto';
//   clearModalInputs();
// });

// // Закрытие по клику на фон
// modalOverlay.addEventListener('click', (e) => {
//   if (e.target === modalOverlay) {
//     modalOverlay.classList.remove('active');
//     document.body.style.overflow = 'auto';
//     clearModalInputs();
//   }
// });

// // Закрытие по Escape
// document.addEventListener('keydown', (e) => {
//   if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
//     modalOverlay.classList.remove('active');
//     document.body.style.overflow = 'auto';
//     clearModalInputs();
//   }
// });

// // Очистка полей модального окна
// function clearModalInputs() {
//   document.getElementById('streamLink').value = '';
//   document.getElementById('codeWord').value = '';
// }

// // ===== СОЗДАНИЕ РОЗЫГРЫША =====

// createBtn.addEventListener('click', async () => {
//   const streamLink = document.getElementById('streamLink').value.trim();
//   const codeWord = document.getElementById('codeWord').value.trim();

//   // Валидация
//   if (!streamLink || !codeWord) {
//     showNotification('❌ Заполните все поля!', 'error');
//     return;
//   }

//   try {
//     // Показываем загрузку
//     createBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> СОЗДАНИЕ...';
//     createBtn.disabled = true;

//     const res = await fetch('http://localhost:3000/raffle/create', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'Accept': 'application/json'
//       },
//       body: JSON.stringify({
//         streamLink,
//         codeWord
//       })
//     });

//     const data = await res.json();

//     if (data.ok) {
//       showNotification(`✅ Розыгрыш создан! ID: ${data.id}`, 'success');
//       modalOverlay.classList.remove('active');
//       document.body.style.overflow = 'auto';
//       clearModalInputs();

//       // Обновляем список розыгрышей
//       loadRaffles();

//       // Подключаемся к этому розыгрышу
//       currentRaffleId = data.id;
//       if (socket) {
//         socket.emit('joinRaffle', data.id);
//       }
//     } else {
//       showNotification(`❌ Ошибка: ${data.error}`, 'error');
//     }
//   } catch (error) {
//     console.error('Error creating raffle:', error);
//     showNotification('❌ Ошибка сети или сервера', 'error');
//   } finally {
//     // Восстанавливаем кнопку
//     createBtn.innerHTML = '<i class="fas fa-bolt"></i> СОЗДАНИЕ';
//     createBtn.disabled = false;
//   }
// });

// // ===== ЗАГРУЗКА И ОТОБРАЖЕНИЕ РОЗЫГРЫШЕЙ =====

// async function loadRaffles() {
//   try {
//     const res = await fetch('http://localhost:3000/raffles');
//     const data = await res.json();

//     if (data.ok && data.raffles.length > 0) {
//       displayRaffles(data.raffles);
//     } else {
//       rafflesList.innerHTML = `
//                 <div class="empty-state">
//                     <i class="fas fa-gift" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.3;"></i>
//                     <p>Нет активных розыгрышей</p>
//                     <p style="font-size: 0.9rem; margin-top: 10px; opacity: 0.6;">
//                         Создайте первый розыгрыш, нажав кнопку выше
//                     </p>
//                 </div>
//             `;
//     }
//   } catch (error) {
//     console.error('Error loading raffles:', error);
//     rafflesList.innerHTML = `
//             <div class="empty-state">
//                 <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 20px; opacity: 0.3;"></i>
//                 <p>Ошибка загрузки розыгрышей</p>
//             </div>
//         `;
//   }
// }

// function displayRaffles(raffles) {
//   rafflesList.innerHTML = '';

//   raffles.forEach(raffle => {
//     const raffleItem = document.createElement('div');
//     raffleItem.className = 'raffle-item';
//     raffleItem.innerHTML = `
//             <div class="raffle-info">
//                 <h4>
//                     <i class="fas fa-gift" style="color: #8a2be2; margin-right: 10px;"></i>
//                     ${raffle.title || 'Розыгрыш ' + raffle.id.substring(0, 8)}
//                 </h4>
//                 <p><strong><i class="fas fa-key"></i> Кодовое слово:</strong> ${raffle.codeWord}</p>
//                 <p><strong><i class="fas fa-users"></i> Участников:</strong> ${raffle.participantCount}</p>
//                 <p><strong><i class="fas fa-link"></i> Ссылка:</strong> 
//                     <a href="${raffle.streamLink}" target="_blank" style="color: #00f5ff; text-decoration: none;">
//                         ${raffle.streamLink.substring(0, 40)}...
//                     </a>
//                 </p>
//             </div>
//             <div class="raffle-actions">
//                 <button class="btn-start" data-id="${raffle.id}">
//                     <i class="fas fa-play"></i> Старт
//                 </button>
//                 <button class="btn-stop" data-id="${raffle.id}">
//                     <i class="fas fa-stop"></i> Стоп
//                 </button>
//                 <button class="btn-select" data-id="${raffle.id}">
//                     <i class="fas fa-eye"></i> Показать
//                 </button>
//             </div>
//         `;

//     rafflesList.appendChild(raffleItem);
//   });

//   // Добавляем обработчики кнопок
//   setupRaffleButtons();
// }

// function setupRaffleButtons() {
//   // Старт розыгрыша
//   document.querySelectorAll('.btn-start').forEach(btn => {
//     btn.addEventListener('click', async () => {
//       const raffleId = btn.dataset.id;
//       await startRaffle(raffleId);
//     });
//   });

//   // Стоп розыгрыша
//   document.querySelectorAll('.btn-stop').forEach(btn => {
//     btn.addEventListener('click', async () => {
//       const raffleId = btn.dataset.id;
//       await stopRaffle(raffleId);
//     });
//   });

//   // Показать участников
//   document.querySelectorAll('.btn-select').forEach(btn => {
//     btn.addEventListener('click', () => {
//       const raffleId = btn.dataset.id;
//       selectRaffle(raffleId);
//     });
//   });
// }

// // ===== УПРАВЛЕНИЕ РОЗЫГРЫШАМИ =====

// async function startRaffle(raffleId) {
//   try {
//     const btn = document.querySelector(`.btn-start[data-id="${raffleId}"]`);
//     btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
//     btn.disabled = true;

//     const res = await fetch(`http://localhost:3000/raffle/${raffleId}/start`, {
//       method: 'POST'
//     });

//     const data = await res.json();

//     if (data.ok) {
//       showNotification('🚀 Бот запущен! Мониторинг чата активен', 'success');
//       if (socket) {
//         socket.emit('joinRaffle', raffleId);
//       }
//       currentRaffleId = raffleId;
//     } else {
//       showNotification(`❌ Ошибка: ${data.error}`, 'error');
//     }
//   } catch (error) {
//     console.error('Error starting raffle:', error);
//     showNotification('❌ Ошибка при запуске бота', 'error');
//   } finally {
//     loadRaffles(); // Обновляем список
//   }
// }

// async function stopRaffle(raffleId) {
//   try {
//     const btn = document.querySelector(`.btn-stop[data-id="${raffleId}"]`);
//     btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
//     btn.disabled = true;

//     const res = await fetch(`http://localhost:3000/raffle/${raffleId}/stop`, {
//       method: 'POST'
//     });

//     const data = await res.json();

//     if (data.ok) {
//       showNotification('🛑 Розыгрыш остановлен', 'warning');
//     } else {
//       showNotification(`❌ Ошибка: ${data.error}`, 'error');
//     }
//   } catch (error) {
//     console.error('Error stopping raffle:', error);
//     showNotification('❌ Ошибка при остановке розыгрыша', 'error');
//   } finally {
//     loadRaffles(); // Обновляем список
//   }
// }

// function selectRaffle(raffleId) {
//   currentRaffleId = raffleId;
//   if (socket) {
//     socket.emit('joinRaffle', raffleId);
//   }
//   loadParticipants(raffleId);

//   // Подсвечиваем выбранный розыгрыш
//   document.querySelectorAll('.raffle-item').forEach(item => {
//     item.style.borderColor = 'rgba(255, 255, 255, 0.1)';
//   });
//   const selectedItem = document.querySelector(`.btn-select[data-id="${raffleId}"]`).closest('.raffle-item');
//   if (selectedItem) {
//     selectedItem.style.borderColor = '#00f5ff';
//     selectedItem.style.boxShadow = '0 0 40px rgba(0, 245, 255, 0.2)';
//   }
// }

// // ===== УЧАСТНИКИ =====

// async function loadParticipants(raffleId) {
//   try {
//     const res = await fetch(`http://localhost:3000/raffle/${raffleId}/participants`);
//     const data = await res.json();

//     if (data.ok) {
//       displayParticipants(data.participants);
//     }
//   } catch (error) {
//     console.error('Error loading participants:', error);
//   }
// }

// function displayParticipants(participants) {
//   if (!participantsList) return;

//   participantsList.innerHTML = '';

//   if (participants.length === 0) {
//     participantsList.innerHTML = `
//             <li style="text-align: center; color: rgba(255, 255, 255, 0.5);">
//                 <i class="fas fa-user-friends" style="font-size: 2rem; display: block; margin-bottom: 10px;"></i>
//                 Пока нет участников
//             </li>
//         `;
//     return;
//   }

//   participants.forEach((participant, index) => {
//     const li = document.createElement('li');
//     li.innerHTML = `
//             <span style="background: rgba(138, 43, 226, 0.2); padding: 5px 10px; border-radius: 10px; font-size: 0.8rem;">
//                 #${index + 1}
//             </span>
//             ${participant}
//         `;
//     participantsList.appendChild(li);
//   });
// }

// // ===== УТИЛИТЫ =====

// function showNotification(message, type = 'info') {
//   // Создаем элемент уведомления
//   const notification = document.createElement('div');
//   notification.className = `notification ${type}`;
//   notification.style.cssText = `
//         position: fixed;
//         top: 30px;
//         right: 30px;
//         background: rgba(16, 18, 27, 0.95);
//         backdrop-filter: blur(20px);
//         padding: 20px 30px;
//         border-radius: 15px;
//         border-left: 4px solid ${type === 'success' ? '#00ff88' : type === 'error' ? '#ff4757' : type === 'warning' ? '#ffaa00' : '#00f5ff'};
//         box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
//         z-index: 10000;
//         animation: slideIn 0.3s ease-out;
//         max-width: 400px;
//         word-wrap: break-word;
//     `;

//   notification.innerHTML = `
//         <div style="display: flex; align-items: center; gap: 15px;">
//             <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}" 
//                style="color: ${type === 'success' ? '#00ff88' : type === 'error' ? '#ff4757' : type === 'warning' ? '#ffaa00' : '#00f5ff'}; 
//                       font-size: 1.2rem;">
//             </i>
//             <span>${message}</span>
//         </div>
//     `;

//   document.body.appendChild(notification);

//   // Удаляем через 5 секунд
//   setTimeout(() => {
//     notification.style.animation = 'slideOut 0.3s ease-out forwards';
//     setTimeout(() => notification.remove(), 300);
//   }, 5000);
// }

// function updateParticipantsCount(count) {
//   // Обновляем бейдж с количеством участников
//   const badge = document.querySelector('.badge-text');
//   if (badge && badge.textContent.includes('участников')) {
//     badge.textContent = `${count} участников`;
//   }
// }

// // ===== ОСНОВНАЯ ИНИЦИАЛИЗАЦИЯ =====

// document.addEventListener('DOMContentLoaded', async () => {
//   console.log('DOMContentLoaded начал работу');

//   const isAuthenticated = await checkAuthentication();
//   console.log('Результат checkAuthentication:', isAuthenticated);

//   if (!isAuthenticated) {
//     console.log('Пользователь не авторизован, перенаправляем...');
//     return; // checkAuthentication уже перенаправит на login.html
//   }

//   console.log('Пользователь авторизован, продолжаем инициализацию');

//   // 1. Инициализируем WebSocket ТОЛЬКО после успешной аутентификации
//   initWebSocket();

//   // 2. Настраиваем UI
//   const user = JSON.parse(localStorage.getItem('user') || '{}');

//   // Обновляем интерфейс с информацией о пользователе
//   const userInfoElement = document.createElement('div');
//   userInfoElement.className = 'user-info';
//   userInfoElement.innerHTML = `
//     <span style="margin-right: 15px; color: var(--text-secondary);">
//       <i class="fas fa-user"></i> ${user.username}
//     </span>
//     <button id="logoutBtn" style="background: transparent; border: 1px solid var(--border-glass); padding: 8px 15px; border-radius: 10px; color: var(--text-secondary); cursor: pointer;">
//       <i class="fas fa-sign-out-alt"></i> Выход
//     </button>
//   `;

//   // Добавляем в заголовок
//   const header = document.querySelector('.app-header');
//   if (header) {
//     header.appendChild(userInfoElement);
//   }

//   // Обработчик выхода
//   document.getElementById('logoutBtn')?.addEventListener('click', () => {
//     window.location.href = 'logout.html';
//   });

//   // 3. Загружаем данные
//   loadRaffles();

//   // 4. Добавляем стили для уведомлений
//   const style = document.createElement('style');
//   style.textContent = `
//     @keyframes slideIn {
//       from {
//         transform: translateX(100%);
//         opacity: 0;
//       }
//       to {
//         transform: translateX(0);
//         opacity: 1;
//       }
//     }
    
//     @keyframes slideOut {
//       from {
//         transform: translateX(0);
//         opacity: 1;
//       }
//       to {
//         transform: translateX(100%);
//         opacity: 0;
//       }
//     }
    
//     .notification {
//       font-family: 'Space Grotesk', sans-serif;
//     }
    
//     .empty-state {
//       grid-column: 1 / -1;
//       text-align: center;
//       padding: 60px 20px;
//       color: rgba(255, 255, 255, 0.5);
//       font-size: 1.1rem;
//     }
//   `;
//   document.head.appendChild(style);

//   console.log('Инициализация завершена успешно');
// });